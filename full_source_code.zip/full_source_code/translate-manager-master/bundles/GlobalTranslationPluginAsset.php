<?php

namespace global\translate\bundles;

use yii\web\AssetBundle;

/**
 * Contains javascript files necessary for translating javascript messages on the client side (`global.t()` calls).
 *
 * @author Author <author@example.com>
 *
 * @since 1.0
 */
class GlobalTranslationPluginAsset extends AssetBundle
{
    /**
     * @inheritdoc
     */
    public $sourcePath = '@global/translate/assets';

    /**
     * @inheritdoc
     */
    public $js = [
        'javascripts/md5.js',
        'javascripts/global.js',
    ];

    /**
     * @inheritdoc
     */
    public $depends = [
        'global\translate\bundles\LanguageItemPluginAsset',
    ];
}
