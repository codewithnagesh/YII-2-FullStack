<?php

namespace global\translate\bundles;

use yii\web\AssetBundle;

/**
 * Contains the translated javascript messages for the current language.
 *
 * @author Author <author@example.com>
 *
 * @since 1.0
 */
class GlobalLanguageItemPluginAsset extends AssetBundle
{
    /**
     * @inheritdoc
     */
    public $sourcePath = '@global/translate/assets';

    /**
     * @inheritdoc
     */
    public $publishOptions = [
        'forceCopy' => true,
    ];

    /**
     * @inheritdoc
     */
    public function init()
    {
        $this->sourcePath = \Yii::$app->getModule('translate')->getLanguageItemsDirPath();
        $language = \Yii::$app->language;

        if (file_exists(\Yii::getAlias($this->sourcePath . $language . '.js'))) {
            $this->js = [$language . '.js'];
        } else {
            $this->sourcePath = null;
        }

        parent::init();
    }
}
